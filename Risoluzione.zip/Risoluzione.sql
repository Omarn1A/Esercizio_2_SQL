select  * from album limit 5;
select count(Name) from track;
select distinct Name from genre;
select track.Name, genre.Name from track inner join genre on track.GenreID=genre.GenreID;
select artist.Name, album.Title from artist inner join album on artist.ArtistId=album.ArtistId;
select artist.Name, album.Title from artist left join album on artist.ArtistId=album.ArtistId where album.Title is Null;
select track.Name, genre.Name, mediatype.Name from track inner join genre on track.GenreId=genre.GenreId inner join mediatype on track.MediaTypeId=mediatype.MediaTypeId;
select artist.Name, album.Title from artist inner join album on artist.ArtistId=album.ArtistId;